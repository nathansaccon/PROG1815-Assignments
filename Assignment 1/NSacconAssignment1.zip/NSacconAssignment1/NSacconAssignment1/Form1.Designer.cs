﻿namespace NSacconAssignment1
{
    partial class SeatingAssignment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnA0 = new System.Windows.Forms.Button();
            this.btnA1 = new System.Windows.Forms.Button();
            this.btnA2 = new System.Windows.Forms.Button();
            this.btnB0 = new System.Windows.Forms.Button();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnC0 = new System.Windows.Forms.Button();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnD0 = new System.Windows.Forms.Button();
            this.btnD1 = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnE0 = new System.Windows.Forms.Button();
            this.btnE1 = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lbxLetters = new System.Windows.Forms.ListBox();
            this.lbxNumbers = new System.Windows.Forms.ListBox();
            this.btnStatus = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.btnBook = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnWaitList = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.txtBoxShowAll = new System.Windows.Forms.RichTextBox();
            this.txtBoxShowWaitList = new System.Windows.Forms.RichTextBox();
            this.btnShowWaitList = new System.Windows.Forms.Button();
            this.btnFillAll = new System.Windows.Forms.Button();
            this.cbxHideBoxes = new System.Windows.Forms.CheckBox();
            this.btnFillWaitList = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnAbout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnA0
            // 
            this.btnA0.Location = new System.Drawing.Point(37, 33);
            this.btnA0.Name = "btnA0";
            this.btnA0.Size = new System.Drawing.Size(52, 50);
            this.btnA0.TabIndex = 0;
            this.btnA0.Text = "A0";
            this.btnA0.UseVisualStyleBackColor = true;
            // 
            // btnA1
            // 
            this.btnA1.Location = new System.Drawing.Point(95, 33);
            this.btnA1.Name = "btnA1";
            this.btnA1.Size = new System.Drawing.Size(52, 50);
            this.btnA1.TabIndex = 1;
            this.btnA1.Text = "A1";
            this.btnA1.UseVisualStyleBackColor = true;
            // 
            // btnA2
            // 
            this.btnA2.Location = new System.Drawing.Point(153, 33);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(52, 50);
            this.btnA2.TabIndex = 2;
            this.btnA2.Text = "A2";
            this.btnA2.UseVisualStyleBackColor = true;
            // 
            // btnB0
            // 
            this.btnB0.Location = new System.Drawing.Point(37, 89);
            this.btnB0.Name = "btnB0";
            this.btnB0.Size = new System.Drawing.Size(52, 50);
            this.btnB0.TabIndex = 3;
            this.btnB0.Text = "B0";
            this.btnB0.UseVisualStyleBackColor = true;
            // 
            // btnB1
            // 
            this.btnB1.Location = new System.Drawing.Point(95, 89);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(52, 50);
            this.btnB1.TabIndex = 4;
            this.btnB1.Text = "B1";
            this.btnB1.UseVisualStyleBackColor = true;
            // 
            // btnB2
            // 
            this.btnB2.Location = new System.Drawing.Point(153, 89);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(52, 50);
            this.btnB2.TabIndex = 5;
            this.btnB2.Text = "B2";
            this.btnB2.UseVisualStyleBackColor = true;
            // 
            // btnC0
            // 
            this.btnC0.Location = new System.Drawing.Point(37, 145);
            this.btnC0.Name = "btnC0";
            this.btnC0.Size = new System.Drawing.Size(52, 50);
            this.btnC0.TabIndex = 6;
            this.btnC0.Text = "C0";
            this.btnC0.UseVisualStyleBackColor = true;
            // 
            // btnC1
            // 
            this.btnC1.Location = new System.Drawing.Point(95, 145);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(52, 50);
            this.btnC1.TabIndex = 7;
            this.btnC1.Text = "C1";
            this.btnC1.UseVisualStyleBackColor = true;
            // 
            // btnC2
            // 
            this.btnC2.Location = new System.Drawing.Point(153, 145);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(52, 50);
            this.btnC2.TabIndex = 8;
            this.btnC2.Text = "C2";
            this.btnC2.UseVisualStyleBackColor = true;
            // 
            // btnD0
            // 
            this.btnD0.Location = new System.Drawing.Point(37, 201);
            this.btnD0.Name = "btnD0";
            this.btnD0.Size = new System.Drawing.Size(52, 50);
            this.btnD0.TabIndex = 9;
            this.btnD0.Text = "D0";
            this.btnD0.UseVisualStyleBackColor = true;
            // 
            // btnD1
            // 
            this.btnD1.Location = new System.Drawing.Point(95, 201);
            this.btnD1.Name = "btnD1";
            this.btnD1.Size = new System.Drawing.Size(52, 50);
            this.btnD1.TabIndex = 10;
            this.btnD1.Text = "D1";
            this.btnD1.UseVisualStyleBackColor = true;
            // 
            // btnD2
            // 
            this.btnD2.Location = new System.Drawing.Point(153, 201);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(52, 50);
            this.btnD2.TabIndex = 11;
            this.btnD2.Text = "D2";
            this.btnD2.UseVisualStyleBackColor = true;
            // 
            // btnE0
            // 
            this.btnE0.Location = new System.Drawing.Point(37, 257);
            this.btnE0.Name = "btnE0";
            this.btnE0.Size = new System.Drawing.Size(52, 50);
            this.btnE0.TabIndex = 12;
            this.btnE0.Text = "E0";
            this.btnE0.UseVisualStyleBackColor = true;
            // 
            // btnE1
            // 
            this.btnE1.Location = new System.Drawing.Point(95, 257);
            this.btnE1.Name = "btnE1";
            this.btnE1.Size = new System.Drawing.Size(52, 50);
            this.btnE1.TabIndex = 13;
            this.btnE1.Text = "E1";
            this.btnE1.UseVisualStyleBackColor = true;
            // 
            // btnE2
            // 
            this.btnE2.Location = new System.Drawing.Point(153, 257);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(52, 50);
            this.btnE2.TabIndex = 14;
            this.btnE2.Text = "E2";
            this.btnE2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(174, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "A";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "B";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "C";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "D";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 276);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "E";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(308, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(270, 25);
            this.label9.TabIndex = 23;
            this.label9.Text = "Airline Reservation System";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(255, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(189, 20);
            this.label10.TabIndex = 24;
            this.label10.Text = "Booking and Cancellation";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(256, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(300, 86);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(199, 20);
            this.txtName.TabIndex = 26;
            // 
            // lbxLetters
            // 
            this.lbxLetters.FormattingEnabled = true;
            this.lbxLetters.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E"});
            this.lbxLetters.Location = new System.Drawing.Point(288, 126);
            this.lbxLetters.Name = "lbxLetters";
            this.lbxLetters.Size = new System.Drawing.Size(35, 69);
            this.lbxLetters.TabIndex = 27;
            // 
            // lbxNumbers
            // 
            this.lbxNumbers.FormattingEnabled = true;
            this.lbxNumbers.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.lbxNumbers.Location = new System.Drawing.Point(351, 126);
            this.lbxNumbers.Name = "lbxNumbers";
            this.lbxNumbers.Size = new System.Drawing.Size(35, 69);
            this.lbxNumbers.TabIndex = 28;
            // 
            // btnStatus
            // 
            this.btnStatus.Location = new System.Drawing.Point(450, 116);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(113, 23);
            this.btnStatus.TabIndex = 29;
            this.btnStatus.Text = "Status";
            this.btnStatus.UseVisualStyleBackColor = true;
            this.btnStatus.Click += new System.EventHandler(this.btnStatus_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.ForeColor = System.Drawing.Color.Red;
            this.txtStatus.Location = new System.Drawing.Point(408, 145);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(200, 64);
            this.txtStatus.TabIndex = 30;
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(288, 215);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(75, 23);
            this.btnBook.TabIndex = 31;
            this.btnBook.Text = "Book";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(369, 215);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 32;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnWaitList
            // 
            this.btnWaitList.Location = new System.Drawing.Point(450, 215);
            this.btnWaitList.Name = "btnWaitList";
            this.btnWaitList.Size = new System.Drawing.Size(158, 23);
            this.btnWaitList.TabIndex = 33;
            this.btnWaitList.Text = "Add To Waiting List";
            this.btnWaitList.UseVisualStyleBackColor = true;
            this.btnWaitList.Click += new System.EventHandler(this.btnWaitList_Click);
            // 
            // btnShowAll
            // 
            this.btnShowAll.Location = new System.Drawing.Point(37, 313);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(168, 23);
            this.btnShowAll.TabIndex = 34;
            this.btnShowAll.Text = "Show All";
            this.btnShowAll.UseVisualStyleBackColor = true;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // txtBoxShowAll
            // 
            this.txtBoxShowAll.Location = new System.Drawing.Point(37, 342);
            this.txtBoxShowAll.Name = "txtBoxShowAll";
            this.txtBoxShowAll.Size = new System.Drawing.Size(168, 157);
            this.txtBoxShowAll.TabIndex = 35;
            this.txtBoxShowAll.Text = "";
            // 
            // txtBoxShowWaitList
            // 
            this.txtBoxShowWaitList.Location = new System.Drawing.Point(272, 313);
            this.txtBoxShowWaitList.Name = "txtBoxShowWaitList";
            this.txtBoxShowWaitList.Size = new System.Drawing.Size(146, 186);
            this.txtBoxShowWaitList.TabIndex = 36;
            this.txtBoxShowWaitList.Text = "";
            // 
            // btnShowWaitList
            // 
            this.btnShowWaitList.Location = new System.Drawing.Point(288, 284);
            this.btnShowWaitList.Name = "btnShowWaitList";
            this.btnShowWaitList.Size = new System.Drawing.Size(104, 23);
            this.btnShowWaitList.TabIndex = 37;
            this.btnShowWaitList.Text = "Show Waiting List";
            this.btnShowWaitList.UseVisualStyleBackColor = true;
            this.btnShowWaitList.Click += new System.EventHandler(this.btnShowWaitList_Click);
            // 
            // btnFillAll
            // 
            this.btnFillAll.Location = new System.Drawing.Point(469, 329);
            this.btnFillAll.Name = "btnFillAll";
            this.btnFillAll.Size = new System.Drawing.Size(105, 50);
            this.btnFillAll.TabIndex = 38;
            this.btnFillAll.Text = "Fill Seats";
            this.btnFillAll.UseVisualStyleBackColor = true;
            this.btnFillAll.Click += new System.EventHandler(this.btnFillAll_Click);
            // 
            // cbxHideBoxes
            // 
            this.cbxHideBoxes.AutoSize = true;
            this.cbxHideBoxes.Location = new System.Drawing.Point(469, 441);
            this.cbxHideBoxes.Name = "cbxHideBoxes";
            this.cbxHideBoxes.Size = new System.Drawing.Size(139, 17);
            this.cbxHideBoxes.TabIndex = 39;
            this.cbxHideBoxes.Text = "Disable Message Boxes";
            this.cbxHideBoxes.UseVisualStyleBackColor = true;
            this.cbxHideBoxes.CheckedChanged += new System.EventHandler(this.cbxHideBoxes_CheckedChanged);
            // 
            // btnFillWaitList
            // 
            this.btnFillWaitList.Location = new System.Drawing.Point(469, 385);
            this.btnFillWaitList.Name = "btnFillWaitList";
            this.btnFillWaitList.Size = new System.Drawing.Size(105, 50);
            this.btnFillWaitList.TabIndex = 40;
            this.btnFillWaitList.Text = "Fill Waiting List";
            this.btnFillWaitList.UseVisualStyleBackColor = true;
            this.btnFillWaitList.Click += new System.EventHandler(this.btnFillWaitList_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(458, 308);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(159, 18);
            this.label12.TabIndex = 41;
            this.label12.Text = "Debug/Testing Options";
            // 
            // btnAbout
            // 
            this.btnAbout.Location = new System.Drawing.Point(469, 464);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(75, 23);
            this.btnAbout.TabIndex = 42;
            this.btnAbout.Text = "About";
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // SeatingAssignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 520);
            this.Controls.Add(this.btnAbout);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnFillWaitList);
            this.Controls.Add(this.cbxHideBoxes);
            this.Controls.Add(this.btnFillAll);
            this.Controls.Add(this.btnShowWaitList);
            this.Controls.Add(this.txtBoxShowWaitList);
            this.Controls.Add(this.txtBoxShowAll);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.btnWaitList);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnBook);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.btnStatus);
            this.Controls.Add(this.lbxNumbers);
            this.Controls.Add(this.lbxLetters);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnE2);
            this.Controls.Add(this.btnE1);
            this.Controls.Add(this.btnE0);
            this.Controls.Add(this.btnD2);
            this.Controls.Add(this.btnD1);
            this.Controls.Add(this.btnD0);
            this.Controls.Add(this.btnC2);
            this.Controls.Add(this.btnC1);
            this.Controls.Add(this.btnC0);
            this.Controls.Add(this.btnB2);
            this.Controls.Add(this.btnB1);
            this.Controls.Add(this.btnB0);
            this.Controls.Add(this.btnA2);
            this.Controls.Add(this.btnA1);
            this.Controls.Add(this.btnA0);
            this.Name = "SeatingAssignment";
            this.Text = "Airline Reservation System";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnA0;
        private System.Windows.Forms.Button btnA1;
        private System.Windows.Forms.Button btnA2;
        private System.Windows.Forms.Button btnB0;
        private System.Windows.Forms.Button btnB1;
        private System.Windows.Forms.Button btnB2;
        private System.Windows.Forms.Button btnC0;
        private System.Windows.Forms.Button btnC1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnD0;
        private System.Windows.Forms.Button btnD1;
        private System.Windows.Forms.Button btnD2;
        private System.Windows.Forms.Button btnE0;
        private System.Windows.Forms.Button btnE1;
        private System.Windows.Forms.Button btnE2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ListBox lbxLetters;
        private System.Windows.Forms.ListBox lbxNumbers;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnWaitList;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.RichTextBox txtBoxShowAll;
        private System.Windows.Forms.RichTextBox txtBoxShowWaitList;
        private System.Windows.Forms.Button btnShowWaitList;
        private System.Windows.Forms.Button btnFillAll;
        private System.Windows.Forms.CheckBox cbxHideBoxes;
        private System.Windows.Forms.Button btnFillWaitList;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnAbout;
    }
}

